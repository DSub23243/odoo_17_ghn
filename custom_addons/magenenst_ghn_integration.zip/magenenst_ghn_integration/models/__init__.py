
from . import res_country_state
from . import res_partner
from . import res_company
from . import res_district
from . import res_ward
from . import sale_order
from . import delivery_carrier
from . import stock_picking
from . import res_config_settings
from . import stock_warehouse
from . import res_country